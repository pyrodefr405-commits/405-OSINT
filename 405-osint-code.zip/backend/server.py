from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException, Query
from fastapi.responses import StreamingResponse
from starlette.middleware.cors import CORSMiddleware
from fastapi import Body
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
import os
import io
import json
import uuid
import base64
import logging
from pathlib import Path
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from urllib.parse import quote

import requests
from PIL import Image
from PIL.ExifTags import TAGS, GPSTAGS

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')

app = FastAPI()
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

INTEL_SYSTEM = (
    "Tu es 405 Intel, l'IA d'investigation OSINT (renseignement en source ouverte) 100% LEGALE de la plateforme 405 OSINT. "
    "Tu aides enqueteurs, journalistes et chercheurs a mener des investigations uniquement sur des sources publiques et ouvertes. "
    "Tes domaines: recherche d'informations publiques sur une personne (reseaux sociaux publics, annuaires, registres), "
    "analyse de metadonnees EXIF, geolocalisation a partir d'indices visuels, recherche WHOIS/DNS/IP, "
    "Google dorks, archives web (Wayback Machine), fuites publiques consultables legalement (HaveIBeenPwned), "
    "verification d'images et de videos. "
    "Tu REFUSES toute demande illegale: piratage, doxxing, harcelement, acces non autorise, usurpation, contournement de vie privee. "
    "Dans ce cas tu expliques brievement pourquoi et proposes une alternative legale. "
    "Reponds TOUJOURS en francais. Style: terminal, concis, structure avec des tirets, comme un rapport de renseignement. "
    "Donne des etapes actionnables et nomme des outils publics concrets."
)

GEO_PROMPT = (
    "Tu es un expert mondial en geolocalisation OSINT (niveau GeoGuessr professionnel). "
    "Analyse cette photo et determine ou elle a pu etre prise. "
    "Examine: vegetation, architecture, signalisation routiere, plaques d'immatriculation, langue visible, "
    "cote de conduite, mobilier urbain, poteaux electriques, relief, meteo/luminosite, sol, marques culturelles. "
    "Structure ta reponse en francais ainsi:\n"
    "1) HYPOTHESES DE LOCALISATION (classees par probabilite, pays/region/ville si possible)\n"
    "2) INDICES OBSERVES justifiant chaque hypothese\n"
    "3) NIVEAU DE CONFIANCE (faible/moyen/eleve) et pourquoi\n"
    "4) CONSEILS pour affiner (autres indices a chercher, outils publics a utiliser)\n"
    "Reste factuel, signale clairement les incertitudes. Style terminal, tirets, pas de fioritures."
)


def sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


def normalize_image(content: bytes) -> bytes:
    img = Image.open(io.BytesIO(content))
    img = img.convert("RGB")
    img.thumbnail((1024, 1024))
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return buf.getvalue()


@api_router.get("/")
async def root():
    return {"message": "405 OSINT API en ligne"}


# ---------- CHAT IA ----------

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None


@api_router.post("/chat")
async def chat(req: ChatRequest):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(500, "Cle LLM non configuree")
    message = req.message.strip()
    if not message:
        raise HTTPException(400, "Message vide")
    session_id = req.session_id or str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    await db.chat_messages.insert_one({"session_id": session_id, "role": "user", "content": message, "timestamp": now})
    history = await db.chat_messages.find({"session_id": session_id}, {"_id": 0}).sort("timestamp", 1).to_list(40)

    async def gen():
        from emergentintegrations.llm.chat import LlmChat, UserMessage, TextDelta, StreamDone
        history_text = "\n".join(
            f"{'Utilisateur' if m['role'] == 'user' else '405 Intel'}: {m['content']}" for m in history[-20:]
        )
        prompt = f"Historique de la conversation:\n{history_text}\n\nReponds au dernier message de l'utilisateur."
        llm = LlmChat(api_key=EMERGENT_LLM_KEY, session_id=session_id, system_message=INTEL_SYSTEM).with_model("openai", "gpt-5.4")
        full = ""
        try:
            async for ev in llm.stream_message(UserMessage(text=prompt)):
                if isinstance(ev, TextDelta):
                    full += ev.content
                    yield sse({"session_id": session_id, "content": ev.content})
                elif isinstance(ev, StreamDone):
                    break
        except Exception as e:
            logger.error(f"chat error: {e}")
            yield sse({"error": "405 Intel est momentanement indisponible. Reessayez."})
            return
        await db.chat_messages.insert_one({
            "session_id": session_id, "role": "assistant", "content": full,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        yield sse({"done": True, "session_id": session_id})

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@api_router.get("/chat/history/{session_id}")
async def chat_history(session_id: str):
    messages = await db.chat_messages.find({"session_id": session_id}, {"_id": 0}).sort("timestamp", 1).to_list(100)
    return {"session_id": session_id, "messages": messages}


# ---------- ANALYSE EXIF ----------

def dms_to_decimal(dms, ref):
    try:
        deg = float(dms[0]) + float(dms[1]) / 60 + float(dms[2]) / 3600
        if ref in ("S", "W"):
            deg = -deg
        return round(deg, 6)
    except Exception:
        return None


@api_router.post("/exif")
async def exif_analysis(file: UploadFile = File(...)):
    content = await file.read()
    if len(content) > 15 * 1024 * 1024:
        raise HTTPException(400, "Fichier trop volumineux (max 15 Mo)")
    try:
        img = Image.open(io.BytesIO(content))
    except Exception:
        raise HTTPException(400, "Fichier image invalide")

    exif = img.getexif()
    metadata = {}
    for tag_id, value in exif.items():
        tag = TAGS.get(tag_id, str(tag_id))
        if tag in ("GPSInfo", "MakerNote"):
            continue
        try:
            metadata[str(tag)] = str(value)
        except Exception:
            pass

    gps = {}
    gps_ifd = {}
    try:
        gps_ifd = exif.get_ifd(0x8825)
        for k, v in gps_ifd.items():
            gps[GPSTAGS.get(k, str(k))] = str(v)
    except Exception:
        pass

    coords = None
    if gps.get("GPSLatitude") and gps.get("GPSLongitude"):
        try:
            lat = dms_to_decimal(gps_ifd.get(2), gps.get("GPSLatitudeRef", "N"))
            lon = dms_to_decimal(gps_ifd.get(4), gps.get("GPSLongitudeRef", "E"))
            if lat is not None and lon is not None:
                coords = {"lat": lat, "lon": lon,
                          "maps_url": f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=16/{lat}/{lon}"}
        except Exception:
            pass

    return {
        "filename": file.filename,
        "format": img.format,
        "size_bytes": len(content),
        "dimensions": f"{img.width} x {img.height}",
        "metadata": metadata,
        "gps_raw": gps,
        "coordinates": coords,
    }


# ---------- GEOLOCALISATION PAR IA ----------

@api_router.post("/geolocate")
async def geolocate(file: UploadFile = File(...)):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(500, "Cle LLM non configuree")
    content = await file.read()
    if len(content) > 15 * 1024 * 1024:
        raise HTTPException(400, "Fichier trop volumineux (max 15 Mo)")
    try:
        jpeg = normalize_image(content)
    except Exception:
        raise HTTPException(400, "Fichier image invalide")
    b64 = base64.b64encode(jpeg).decode()
    session_id = f"geo-{uuid.uuid4()}"

    async def gen():
        from emergentintegrations.llm.chat import LlmChat, UserMessage, ImageContent, TextDelta, StreamDone
        llm = LlmChat(api_key=EMERGENT_LLM_KEY, session_id=session_id, system_message=GEO_PROMPT).with_model("openai", "gpt-5.4")
        try:
            async for ev in llm.stream_message(UserMessage(
                text="Analyse cette photo et localise l'endroit.",
                file_contents=[ImageContent(image_base64=b64)],
            )):
                if isinstance(ev, TextDelta):
                    yield sse({"content": ev.content})
                elif isinstance(ev, StreamDone):
                    break
        except Exception as e:
            logger.error(f"geolocate error: {e}")
            yield sse({"error": "Analyse indisponible. Reessayez."})
            return
        yield sse({"done": True})

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ---------- TRACAGE IP ----------

@api_router.get("/ip-lookup")
async def ip_lookup(ip: str = Query(default="")):
    target = ip.strip()
    try:
        r = requests.get(
            f"http://ip-api.com/json/{target}?lang=fr&fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,proxy,hosting,query",
            timeout=10,
        )
        data = r.json()
    except Exception:
        raise HTTPException(502, "Service de geolocalisation IP indisponible")
    if data.get("status") == "fail":
        raise HTTPException(400, data.get("message", "IP invalide"))
    return data


# ---------- RECHERCHE IDENTITE ----------

@api_router.get("/name-search")
async def name_search(prenom: str = Query(default=""), nom: str = Query(default="")):
    full = f"{prenom.strip()} {nom.strip()}".strip()
    if not full:
        raise HTTPException(400, "Renseignez au moins un prenom ou un nom")
    q = quote(full)
    sources = [
        {"source": "Google (recherche exacte)", "url": f"https://www.google.com/search?q=%22{q}%22",
         "description": "Mentions publiques du nom entre guillemets: presse, sites, documents."},
        {"source": "PagesJaunes (annuaire officiel FR)", "url": f"https://www.pagesjaunes.fr/pagesblanches/recherche?quoiqui={q}",
         "description": "Annuaire telephonique public francais."},
        {"source": "LinkedIn", "url": f"https://www.linkedin.com/search/results/people/?keywords={q}",
         "description": "Profils professionnels publics."},
        {"source": "Copains d'avant", "url": f"https://copainsdavant.linternaute.com/s/?q={q}",
         "description": "Annuaire public de personnes en France."},
        {"source": "Pappers (dirigeants & entreprises)", "url": f"https://www.pappers.fr/recherche?q={q}",
         "description": "Registres publics d'entreprises francaises."},
        {"source": "Facebook (annuaire public)", "url": f"https://www.facebook.com/public/{q}",
         "description": "Profils publics indexes."},
        {"source": "Google Images", "url": f"https://www.google.com/search?q=%22{q}%22&tbm=isch",
         "description": "Photos publiquement indexees."},
        {"source": "Google Dork reseaux sociaux", "url": f"https://www.google.com/search?q=%22{q}%22+site%3Atwitter.com+OR+site%3Ainstagram.com+OR+site%3Atiktok.com",
         "description": "Recherche ciblee sur les reseaux sociaux publics."},
    ]
    return {"query": full, "sources": sources}


# ---------- RECHERCHE INVERSEE D'IMAGE ----------

@api_router.get("/reverse-search")
async def reverse_search(image_url: str = Query(default="")):
    url = image_url.strip()
    if not url.startswith("http"):
        raise HTTPException(400, "Collez une URL d'image valide (https://...)")
    u = quote(url, safe="")
    sources = [
        {"source": "Google Lens", "url": f"https://lens.google.com/uploadbyurl?url={u}",
         "description": "Le plus puissant pour retrouver l'origine d'une image."},
        {"source": "TinEye", "url": f"https://tineye.com/search?url={u}",
         "description": "Specialiste de la recherche inversee, montre l'historique des publications."},
        {"source": "Yandex Images", "url": f"https://yandex.com/images/search?rpt=imageview&url={u}",
         "description": "Tres fort sur les visages et les lieux."},
        {"source": "Bing Visual Search", "url": f"https://www.bing.com/images/search?view=detailv2&iss=sbi&q=imgurl:{u}",
         "description": "Alternative Microsoft, utile en complement."},
    ]
    return {"image_url": url, "sources": sources}


# ---------- RAPPORT D'ENQUETE PDF ----------

@api_router.post("/report")
async def build_report(payload: dict = Body(...)):
    from xml.sax.saxutils import escape
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import ParagraphStyle

    title_style = ParagraphStyle("t", fontName="Helvetica-Bold", fontSize=20, spaceAfter=4)
    sub_style = ParagraphStyle("s", fontName="Helvetica-Oblique", fontSize=8, spaceAfter=10)
    h_style = ParagraphStyle("h", fontName="Helvetica-Bold", fontSize=13, spaceBefore=16, spaceAfter=6)
    b_style = ParagraphStyle("b", fontName="Helvetica", fontSize=9, leading=14)

    def kv(label, value):
        return Paragraph(f"<b>{escape(str(label))} :</b> {escape(str(value))}", b_style)

    story = [
        Paragraph("405 OSINT — RAPPORT D'ENQUETE", title_style),
        Paragraph(f"Genere le {datetime.now(timezone.utc).strftime('%d/%m/%Y a %H:%M')} UTC — sources publiques uniquement", sub_style),
    ]

    ip = payload.get("ip")
    if ip:
        story.append(Paragraph("TRACAGE IP", h_style))
        for label, key in [("Adresse IP", "query"), ("Pays", "country"), ("Region", "regionName"), ("Ville", "city"),
                           ("Code postal", "zip"), ("FAI", "isp"), ("Organisation", "org"), ("Reseau (AS)", "as")]:
            if ip.get(key):
                story.append(kv(label, ip[key]))
        if ip.get("lat") is not None:
            story.append(kv("Coordonnees (approx.)", f"{ip['lat']}, {ip['lon']}"))
        if ip.get("proxy") or ip.get("hosting"):
            flags = [f for f, on in [("Proxy/VPN", ip.get("proxy")), ("Hebergeur/datacenter", ip.get("hosting"))] if on]
            story.append(kv("Alerte", " — ".join(flags)))

    exif = payload.get("exif")
    if exif:
        story.append(Paragraph("ANALYSE EXIF", h_style))
        for label, key in [("Fichier", "fichier"), ("Format", "format"), ("Dimensions", "dimensions")]:
            if exif.get(key):
                story.append(kv(label, exif[key]))
        story.append(kv("Coordonnees GPS", exif.get("gps") or "Non detectees"))
        for k, v in (exif.get("metadonnees") or []):
            story.append(kv(k, v))

    geo = payload.get("geo")
    if geo and geo.get("texte"):
        story.append(Paragraph("GEOLOCALISATION VISUELLE (IA)", h_style))
        for line in str(geo["texte"])[:4000].split("\n"):
            if line.strip():
                story.append(Paragraph(escape(line.strip()), b_style))

    story.append(Spacer(1, 18))
    story.append(Paragraph("Document genere automatiquement par 405 OSINT. Usage legal uniquement — RGPD applicable.", sub_style))

    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=A4, title="Rapport 405 OSINT").build(story)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": "attachment; filename=rapport-405-osint.pdf"})


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
