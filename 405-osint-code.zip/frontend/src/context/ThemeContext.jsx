import { createContext, useContext, useEffect, useState } from "react";

const ThemeContext = createContext({ theme: "noir", toggle: () => {} });

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => localStorage.getItem("argus_theme") || "noir");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("argus_theme", theme);
  }, [theme]);

  const toggle = () => setTheme((t) => (t === "noir" ? "rouge" : "noir"));

  return <ThemeContext.Provider value={{ theme, toggle }}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => useContext(ThemeContext);
