import { createContext, useContext, useState } from "react";

const CaseContext = createContext({ caseData: {}, record: () => {} });

export function CaseProvider({ children }) {
  const [caseData, setCaseData] = useState({});
  const record = (key, value) => setCaseData((prev) => ({ ...prev, [key]: value }));
  return <CaseContext.Provider value={{ caseData, record }}>{children}</CaseContext.Provider>;
}

export const useCase = () => useContext(CaseContext);
