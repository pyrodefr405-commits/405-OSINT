import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/context/ThemeContext";
import { CaseProvider } from "@/context/CaseContext";
import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import Tools from "@/components/Tools";
import ChatSection from "@/components/ChatSection";
import Faq from "@/components/Faq";
import Footer from "@/components/Footer";
import CustomCursor from "@/components/CustomCursor";
import ReportButton from "@/components/ReportButton";

function Landing() {
  return (
    <div className="min-h-screen bg-[var(--c-bg)] text-white scanlines" data-testid="landing-page">
      <Nav />
      <Hero />
      <Marquee />
      <Tools />
      <ChatSection />
      <Faq />
      <Footer />
      <ReportButton />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <CaseProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Landing />} />
          </Routes>
          <Toaster theme="dark" position="bottom-right" />
        </BrowserRouter>
        <CustomCursor />
      </CaseProvider>
    </ThemeProvider>
  );
}
