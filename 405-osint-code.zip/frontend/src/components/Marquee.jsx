const ITEMS = [
  "405 OSINT",
  "Surveillance active",
  "Sources ouvertes uniquement",
  "100% légal — RGPD",
  "Analyse EXIF",
  "405 Intel en ligne",
  "Traçage IP",
  "Discord : y8dqq",
];

export default function Marquee() {
  const row = ITEMS.join("   ///   ");
  return (
    <div className="relative z-10 border-y border-[var(--c-border)] bg-[var(--c-bg)] overflow-hidden py-3" data-testid="marquee">
      <div className="marquee-track flex whitespace-nowrap text-[0.6rem] uppercase tracking-[0.35em] text-[var(--c-faint)]">
        <span className="pr-10">{row}   ///   </span>
        <span className="pr-10">{row}   ///   </span>
      </div>
    </div>
  );
}
