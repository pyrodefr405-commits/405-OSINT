import { Terminal, ShieldCheck, Flame, Moon } from "lucide-react";
import { useTheme } from "@/context/ThemeContext";

export default function Nav() {
  const { theme, toggle } = useTheme();
  return (
    <nav data-testid="main-nav" className="fixed top-0 left-0 right-0 z-50 bg-[var(--c-bg)] border-b border-[var(--c-border)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 h-14 flex items-center justify-between">
        <a href="#top" data-testid="nav-logo" className="flex items-center gap-2">
          <Terminal className="w-4 h-4" />
          <span className="font-display text-lg tracking-wider">405 OSINT</span>
        </a>
        <div className="flex items-center gap-4 sm:gap-5 text-[0.65rem] uppercase tracking-[0.25em] text-[var(--c-muted)]">
          <a data-testid="nav-link-outils" href="#outils" className="hidden sm:inline hover:text-white transition-colors duration-200">Modules</a>
          <a data-testid="nav-link-chat" href="#ia" className="hover:text-white transition-colors duration-200">IA Enquêtrice</a>
          <a data-testid="nav-link-faq" href="#faq" className="hidden sm:inline hover:text-white transition-colors duration-200">FAQ</a>
          <a data-testid="nav-link-contact" href="#contact" className="hidden sm:inline hover:text-white transition-colors duration-200">Contact</a>
          <button type="button" data-testid="theme-toggle" onClick={toggle}
            className="flex items-center gap-1.5 border border-[var(--c-border)] px-2 py-1 text-white hover:border-[var(--c-accent)] hover:text-[var(--c-accent)] transition-colors duration-200">
            {theme === "noir" ? <Flame className="w-3 h-3" /> : <Moon className="w-3 h-3" />}
            <span>{theme === "noir" ? "Rouge" : "Noir"}</span>
          </button>
          <span className="hidden md:flex items-center gap-1 text-white border border-[var(--c-border)] px-2 py-1">
            <ShieldCheck className="w-3 h-3" /> 100% Légal
          </span>
        </div>
      </div>
    </nav>
  );
}
