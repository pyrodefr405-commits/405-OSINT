import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

export default function SuckSection({ children, className = "", mode = "both" }) {
  const ref = useRef(null);
  const isExit = mode === "exit";
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: isExit ? ["start start", "end start"] : ["start end", "end start"],
  });
  const scale = useTransform(
    scrollYProgress,
    isExit ? [0, 1] : [0, 0.3, 0.75, 1],
    isExit ? [1, 0.78] : [0.88, 1, 1, 0.85]
  );
  const opacity = useTransform(
    scrollYProgress,
    isExit ? [0.35, 1] : [0, 0.22, 0.8, 1],
    isExit ? [1, 0] : [0, 1, 1, 0.04]
  );
  const y = useTransform(
    scrollYProgress,
    isExit ? [0, 1] : [0, 0.3],
    isExit ? [0, -90] : [70, 0]
  );

  return (
    <motion.div ref={ref} style={{ scale, opacity, y }} className={className}>
      {children}
    </motion.div>
  );
}
