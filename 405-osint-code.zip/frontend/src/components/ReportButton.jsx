import { useState } from "react";
import { FileDown } from "lucide-react";
import { toast } from "sonner";
import { API } from "@/lib/api";
import { useCase } from "@/context/CaseContext";

export default function ReportButton() {
  const { caseData } = useCase();
  const [loading, setLoading] = useState(false);

  if (Object.keys(caseData).length === 0) return null;

  const download = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/report`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(caseData),
      });
      if (!res.ok) throw new Error("Génération du rapport impossible");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `rapport-405-osint-${Date.now()}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Rapport d'enquête téléchargé");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      type="button"
      data-testid="report-export-btn"
      onClick={download}
      disabled={loading}
      className="btn-brutal fixed bottom-5 left-5 z-50 !bg-[var(--c-bg)] flex items-center gap-2 shadow-none"
    >
      <FileDown className="w-3.5 h-3.5" />
      {loading ? "Génération..." : "Rapport PDF"}
    </button>
  );
}
