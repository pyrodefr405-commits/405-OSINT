import { ShieldCheck, MessageSquare, Scale } from "lucide-react";
import SuckSection from "@/components/SuckSection";

export default function Footer() {
  return (
    <footer id="contact" data-testid="footer" className="border-t border-[var(--c-border)] bg-[var(--c-bg)]">
      <SuckSection>
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-16 grid grid-cols-1 md:grid-cols-3 gap-px bg-[var(--c-border)] border border-[var(--c-border)]">
          <div className="bg-[var(--c-surface)] p-8">
            <p className="text-[0.6rem] uppercase tracking-[0.3em] text-[var(--c-faint)] mb-3 flex items-center gap-2">
              <MessageSquare className="w-3 h-3" /> Contact sécurisé
            </p>
            <p className="font-display uppercase text-3xl" data-testid="footer-discord">Discord : y8dqq</p>
            <p className="text-xs text-[var(--c-muted)] mt-3 font-light">Questions, signalements, demandes de fonctionnalités.</p>
          </div>
          <div className="bg-[var(--c-surface)] p-8">
            <p className="text-[0.6rem] uppercase tracking-[0.3em] text-[var(--c-faint)] mb-3 flex items-center gap-2">
              <ShieldCheck className="w-3 h-3" /> Engagement
            </p>
            <p className="text-xs text-[var(--c-muted)] font-light leading-relaxed">
              ARGUS n'utilise que des données publiques et ouvertes. Aucune base illégale, aucun contournement de la vie privée.
            </p>
          </div>
          <div className="bg-[var(--c-surface)] p-8">
            <p className="text-[0.6rem] uppercase tracking-[0.3em] text-[var(--c-faint)] mb-3 flex items-center gap-2">
              <Scale className="w-3 h-3" /> Cadre légal
            </p>
            <p className="text-xs text-[var(--c-muted)] font-light leading-relaxed">
              Usage réservé aux enquêtes légitimes : journalisme, cybersécurité défensive, recherche. Le RGPD s'applique.
            </p>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <span className="font-display uppercase tracking-wider">405 OSINT</span>
          <span className="text-[0.6rem] uppercase tracking-[0.25em] text-[var(--c-faint)]">Réseau neural d'investigation — 2026</span>
        </div>
      </SuckSection>
    </footer>
  );
}
