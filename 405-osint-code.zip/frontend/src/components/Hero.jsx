import { useEffect, useState } from "react";
import { Eye, FileSearch, MapPin, Globe, UserSearch, ChevronDown } from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import SuckSection from "@/components/SuckSection";

const MODULES = [
  { icon: FileSearch, label: "Analyse EXIF" },
  { icon: MapPin, label: "Géoloc. photo IA" },
  { icon: Globe, label: "Traçage IP" },
  { icon: UserSearch, label: "Recherche identité" },
];

export default function Hero() {
  const { theme } = useTheme();
  const [booted, setBooted] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setBooted(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <header id="top" data-testid="hero-section" className="relative min-h-screen flex items-end overflow-hidden grain">
      <div
        className={`absolute inset-0 bg-cover bg-center transition-opacity duration-700 ease-out ${theme === "noir" ? "opacity-100" : "opacity-0"}`}
        style={{ backgroundImage: "url(/theme-noir.jpg)", filter: "grayscale(1) brightness(1.2) contrast(1.05)" }}
        data-testid="hero-bg-noir"
      />
      <div
        className={`absolute inset-0 bg-cover bg-center transition-opacity duration-700 ease-out ${theme === "rouge" ? "opacity-100" : "opacity-0"}`}
        style={{ backgroundImage: "url(/theme-rouge.jpg)", filter: "brightness(0.95) contrast(1.05)" }}
        data-testid="hero-bg-rouge"
      />
      <div
        className="absolute inset-0 transition-colors duration-700"
        style={{ backgroundColor: theme === "rouge" ? "rgba(22,2,2,0.55)" : "rgba(0,0,0,0.6)" }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[var(--c-bg)] via-transparent to-black/50" />

      <SuckSection mode="exit" className="relative z-10 w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 pb-20 pt-40">
          <p className="text-[0.65rem] uppercase tracking-[0.35em] text-[var(--c-muted)] mb-6 fade-up" data-testid="hero-eyebrow">
            // 405 OSINT — Renseignement en source ouverte
          </p>
          <h1
            data-testid="hero-title"
            className={`font-display uppercase leading-[0.9] tracking-tight text-6xl sm:text-8xl lg:text-9xl ${booted ? "glitch" : "opacity-0"}`}
          >
            Réseau neural<br />d'investigation
          </h1>
          <p className="mt-8 max-w-xl text-sm sm:text-base font-light text-[var(--c-muted)] leading-relaxed fade-up" style={{ animationDelay: "0.3s" }} data-testid="hero-subtitle">
            Une photo. Une IP. Un nom. 405 OSINT croise les <span className="redacted">sources ouvertes</span> et
            son IA de vision localise un lieu rien qu'à partir d'une image. Légal, public, traçable.
          </p>
          <div className="mt-10 flex flex-wrap gap-4 fade-up" style={{ animationDelay: "0.45s" }}>
            <a href="#outils" data-testid="hero-cta-outils" className="btn-brutal">Lancer l'enquête</a>
            <a href="#ia" data-testid="hero-cta-chat" className="btn-brutal !border-[var(--c-faint)] !text-[var(--c-muted)] hover:!border-[var(--c-accent)] hover:!text-black">Parler à l'IA</a>
          </div>

          <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 border border-[var(--c-border)] divide-x divide-y sm:divide-y-0 divide-[var(--c-border)] fade-up" style={{ animationDelay: "0.6s" }} data-testid="hero-modules-strip">
            {MODULES.map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-3 px-4 py-4 bg-black/60">
                <Icon className="w-4 h-4 text-[var(--c-muted)] shrink-0" />
                <span className="text-[0.6rem] uppercase tracking-[0.2em] text-[var(--c-muted)]">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </SuckSection>

      <div className="absolute bottom-6 right-8 hidden md:flex items-center gap-2 text-[0.6rem] uppercase tracking-[0.3em] text-[var(--c-faint)] z-10">
        <Eye className="w-3 h-3" /> Surveillance active <ChevronDown className="w-3 h-3 animate-bounce" />
      </div>
    </header>
  );
}
