import { useState } from "react";
import { Globe, Radar } from "lucide-react";
import { toast } from "sonner";
import { API } from "@/lib/api";
import { useCase } from "@/context/CaseContext";

const FIELDS = [
  ["query", "Adresse IP"], ["country", "Pays"], ["regionName", "Région"], ["city", "Ville"],
  ["zip", "Code postal"], ["timezone", "Fuseau"], ["isp", "FAI"], ["org", "Organisation"], ["as", "AS"],
];

export default function IpLookup() {
  const [ip, setIp] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const { record } = useCase();

  const lookup = async () => {
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch(`${API}/ip-lookup?ip=${encodeURIComponent(ip)}`);
      if (!res.ok) throw new Error((await res.json()).detail || "Recherche impossible");
      const data = await res.json();
      setResult(data);
      record("ip", data);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[var(--c-surface)] p-6 sm:p-8" data-testid="ip-tool">
      <div className="flex items-baseline justify-between mb-6">
        <h3 className="font-display uppercase text-xl sm:text-2xl flex items-center gap-3">
          <Globe className="w-5 h-5 text-[var(--c-muted)]" /> Traçage IP
        </h3>
        <span className="text-[0.6rem] tracking-[0.3em] text-[var(--c-faint)]">03</span>
      </div>
      <p className="text-xs text-[var(--c-muted)] font-light mb-6 leading-relaxed">
        Géolocalisation approximative, FAI et réseau d'une adresse IP. Vide = votre propre IP.
      </p>
      <div className="flex flex-col sm:flex-row gap-3">
        <input data-testid="ip-input" className="input-brutal flex-1" placeholder="ex : 8.8.8.8 (vide = votre IP)"
          value={ip} onChange={(e) => setIp(e.target.value)} onKeyDown={(e) => e.key === "Enter" && lookup()} />
        <button type="button" data-testid="ip-search-btn" onClick={lookup} disabled={loading} className="btn-brutal flex items-center gap-2">
          <Radar className="w-3 h-3" /> {loading ? "Traçage..." : "Tracer"}
        </button>
      </div>
      {result && (
        <div className="mt-6 border border-[var(--c-border)]" data-testid="ip-results">
          <div className="max-h-64 overflow-y-auto text-xs">
            {FIELDS.map(([key, label]) => result[key] ? (
              <div key={key} className="grid grid-cols-[130px_1fr] gap-2 px-4 py-1.5 border-b border-[var(--c-border-soft)]">
                <span className="text-[var(--c-faint)] uppercase text-[0.6rem] tracking-widest">{label}</span>
                <span className="text-[var(--c-text2)]">{result[key]}</span>
              </div>
            ) : null)}
            <div className="grid grid-cols-[130px_1fr] gap-2 px-4 py-1.5 border-b border-[var(--c-border-soft)]">
              <span className="text-[var(--c-faint)] uppercase text-[0.6rem] tracking-widest">Coordonnées</span>
              <a data-testid="ip-map-link" className="text-[var(--c-accent)] underline" target="_blank" rel="noreferrer"
                href={`https://www.openstreetmap.org/?mlat=${result.lat}&mlon=${result.lon}#map=12/${result.lat}/${result.lon}`}>
                {result.lat}, {result.lon} →
              </a>
            </div>
            {(result.proxy || result.hosting) && (
              <div className="px-4 py-3 bg-[var(--c-accent)] text-black text-[0.6rem] uppercase tracking-[0.25em] font-bold" data-testid="ip-alert">
                {result.proxy ? "Proxy / VPN détecté" : ""}{result.proxy && result.hosting ? " — " : ""}{result.hosting ? "Hébergeur / datacenter" : ""}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
