import { useRef, useState } from "react";
import { FileSearch, Upload, MapPin } from "lucide-react";
import { toast } from "sonner";
import { API } from "@/lib/api";
import { useCase } from "@/context/CaseContext";

export default function ExifTool() {
  const inputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const { record } = useCase();

  const analyze = async () => {
    if (!file) return toast.error("Sélectionnez une photo d'abord");
    setLoading(true);
    setResult(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch(`${API}/exif`, { method: "POST", body: fd });
      if (!res.ok) throw new Error((await res.json()).detail || "Erreur d'analyse");
      const data = await res.json();
      setResult(data);
      record("exif", {
        fichier: data.filename,
        format: data.format,
        dimensions: data.dimensions,
        gps: data.coordinates ? `${data.coordinates.lat}, ${data.coordinates.lon}` : null,
        metadonnees: Object.entries(data.metadata).slice(0, 12),
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[var(--c-surface)] p-6 sm:p-8" data-testid="exif-tool">
      <div className="flex items-baseline justify-between mb-6">
        <h3 className="font-display uppercase text-xl sm:text-2xl flex items-center gap-3">
          <FileSearch className="w-5 h-5 text-[var(--c-muted)]" /> Analyse EXIF
        </h3>
        <span className="text-[0.6rem] tracking-[0.3em] text-[var(--c-faint)]">01</span>
      </div>
      <p className="text-xs text-[var(--c-muted)] font-light mb-6 leading-relaxed">
        Extrait les métadonnées cachées d'une photo : appareil, date, logiciel, coordonnées GPS.
      </p>
      <div className="flex flex-col sm:flex-row gap-3">
        <button type="button" data-testid="exif-file-btn" onClick={() => inputRef.current?.click()} className="btn-brutal flex items-center justify-center gap-2 flex-1">
          <Upload className="w-3 h-3" /> {file ? file.name.slice(0, 24) : "Choisir une photo"}
        </button>
        <input ref={inputRef} type="file" accept="image/*" className="hidden" data-testid="exif-file-input"
          onChange={(e) => { setFile(e.target.files?.[0] || null); setResult(null); }} />
        <button type="button" data-testid="exif-analyze-btn" onClick={analyze} disabled={loading} className="btn-brutal">
          {loading ? "Extraction..." : "Extraire"}
        </button>
      </div>
      {result && (
        <div className="mt-6 border border-[var(--c-border)]" data-testid="exif-results">
          <div className="px-4 py-2 border-b border-[var(--c-border)] text-[0.6rem] uppercase tracking-[0.3em] text-[var(--c-muted)]">
            {result.filename} — {result.format} — {result.dimensions} — {(result.size_bytes / 1024).toFixed(1)} Ko
          </div>
          <div className="max-h-64 overflow-y-auto text-xs">
            {Object.keys(result.metadata).length === 0 && !result.coordinates && (
              <p className="px-4 py-4 text-[var(--c-muted)]" data-testid="exif-empty">Aucune métadonnée EXIF trouvée (souvent supprimée par les réseaux sociaux).</p>
            )}
            {Object.entries(result.metadata).map(([k, v]) => (
              <div key={k} className="grid grid-cols-[130px_1fr] gap-2 px-4 py-1.5 border-b border-[var(--c-border-soft)]">
                <span className="text-[var(--c-faint)] uppercase text-[0.6rem] tracking-widest truncate">{k}</span>
                <span className="text-[var(--c-text2)] break-all">{v}</span>
              </div>
            ))}
            {result.coordinates && (
              <div className="px-4 py-3 bg-[var(--c-accent)] text-black" data-testid="exif-gps">
                <p className="text-[0.6rem] uppercase tracking-[0.3em] font-bold flex items-center gap-2">
                  <MapPin className="w-3 h-3" /> GPS détecté : {result.coordinates.lat}, {result.coordinates.lon}
                </p>
                <a href={result.coordinates.maps_url} target="_blank" rel="noreferrer" data-testid="exif-gps-link" className="underline text-xs font-bold mt-1 inline-block">
                  Ouvrir sur OpenStreetMap →
                </a>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
