import { useState } from "react";
import { ScanSearch, ExternalLink, Search, ImageUp } from "lucide-react";
import { toast } from "sonner";
import { API } from "@/lib/api";

export default function ReverseSearch() {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const search = async () => {
    if (!url.trim().startsWith("http")) return toast.error("Colle l'URL d'une image en ligne (https://...)");
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch(`${API}/reverse-search?image_url=${encodeURIComponent(url)}`);
      if (!res.ok) throw new Error((await res.json()).detail || "Recherche impossible");
      setResult(await res.json());
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[var(--c-surface)] p-6 sm:p-8 lg:col-span-2" data-testid="reverse-tool">
      <div className="flex items-baseline justify-between mb-6">
        <h3 className="font-display uppercase text-xl sm:text-2xl flex items-center gap-3">
          <ScanSearch className="w-5 h-5 text-[var(--c-muted)]" /> Recherche inversée
        </h3>
        <span className="text-[0.6rem] tracking-[0.3em] text-[var(--c-faint)]">05</span>
      </div>
      <p className="text-xs text-[var(--c-muted)] font-light mb-6 leading-relaxed">
        Retrouve où une image a déjà été publiée : colle l'URL d'une image en ligne et interroge Google Lens, TinEye, Yandex et Bing.
      </p>
      <div className="flex flex-col sm:flex-row gap-3">
        <input data-testid="reverse-url-input" className="input-brutal flex-1" placeholder="https://exemple.com/photo.jpg"
          value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} />
        <button type="button" data-testid="reverse-search-btn" onClick={search} disabled={loading} className="btn-brutal flex items-center gap-2">
          <Search className="w-3 h-3" /> {loading ? "Préparation..." : "Retrouver les origines"}
        </button>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-3 text-[0.65rem] text-[var(--c-faint)]">
        <ImageUp className="w-3.5 h-3.5" />
        <span>Photo sur ton appareil ? Dépose-la directement sur</span>
        <a href="https://lens.google.com" target="_blank" rel="noreferrer" data-testid="reverse-lens-link" className="underline text-[var(--c-accent)]">Google Lens</a>
        <span>ou</span>
        <a href="https://tineye.com" target="_blank" rel="noreferrer" data-testid="reverse-tineye-link" className="underline text-[var(--c-accent)]">TinEye</a>
      </div>
      {result && (
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-[var(--c-border)] border border-[var(--c-border)]" data-testid="reverse-results">
          {result.sources.map((s) => (
            <a key={s.source} href={s.url} target="_blank" rel="noreferrer" data-testid={`reverse-source-${s.source.toLowerCase().replace(/[^a-z]/g, "-")}`}
              className="bg-[var(--c-surface)] px-4 py-4 hover:bg-[var(--c-accent)] hover:text-black transition-colors duration-200 group">
              <p className="text-xs font-bold uppercase tracking-wider flex items-center justify-between">
                {s.source} <ExternalLink className="w-3 h-3" />
              </p>
              <p className="text-[0.65rem] text-[var(--c-muted)] group-hover:text-black mt-1.5 leading-relaxed transition-colors duration-200">{s.description}</p>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
