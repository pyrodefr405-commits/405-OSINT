import { useState } from "react";
import { UserSearch, ExternalLink, Search } from "lucide-react";
import { toast } from "sonner";
import { API } from "@/lib/api";

export default function NameSearch() {
  const [prenom, setPrenom] = useState("");
  const [nom, setNom] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const search = async () => {
    if (!prenom.trim() && !nom.trim()) return toast.error("Entrez un prénom et/ou un nom");
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch(`${API}/name-search?prenom=${encodeURIComponent(prenom)}&nom=${encodeURIComponent(nom)}`);
      if (!res.ok) throw new Error((await res.json()).detail || "Recherche impossible");
      setResult(await res.json());
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[var(--c-surface)] p-6 sm:p-8" data-testid="name-tool">
      <div className="flex items-baseline justify-between mb-6">
        <h3 className="font-display uppercase text-xl sm:text-2xl flex items-center gap-3">
          <UserSearch className="w-5 h-5 text-[var(--c-muted)]" /> Recherche identité
        </h3>
        <span className="text-[0.6rem] tracking-[0.3em] text-[var(--c-faint)]">04</span>
      </div>
      <p className="text-xs text-[var(--c-muted)] font-light mb-6 leading-relaxed">
        Génère des requêtes ciblées vers les annuaires et registres publics français à partir d'un nom.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <input data-testid="name-prenom-input" className="input-brutal" placeholder="Prénom"
          value={prenom} onChange={(e) => setPrenom(e.target.value)} />
        <input data-testid="name-nom-input" className="input-brutal" placeholder="Nom"
          value={nom} onChange={(e) => setNom(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} />
      </div>
      <button type="button" data-testid="name-search-btn" onClick={search} disabled={loading} className="btn-brutal mt-3 flex items-center gap-2">
        <Search className="w-3 h-3" /> {loading ? "Recherche..." : "Interroger les sources"}
      </button>
      {result && (
        <div className="mt-6 border border-[var(--c-border)]" data-testid="name-results">
          <div className="px-4 py-2 border-b border-[var(--c-border)] text-[0.6rem] uppercase tracking-[0.3em] text-[var(--c-muted)]">
            Cible : {result.query} — {result.sources.length} sources publiques
          </div>
          <div className="max-h-64 overflow-y-auto">
            {result.sources.map((s) => (
              <a key={s.source} href={s.url} target="_blank" rel="noreferrer" data-testid={`name-source-${s.source.slice(0, 10).toLowerCase().replace(/[^a-z]/g, "-")}`}
                className="flex items-start justify-between gap-3 px-4 py-3 border-b border-[var(--c-border-soft)] hover:bg-[var(--c-accent)] hover:text-black transition-colors duration-200 group">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider">{s.source}</p>
                  <p className="text-[0.65rem] text-[var(--c-muted)] group-hover:text-black mt-0.5 transition-colors duration-200">{s.description}</p>
                </div>
                <ExternalLink className="w-3 h-3 mt-1 shrink-0" />
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
