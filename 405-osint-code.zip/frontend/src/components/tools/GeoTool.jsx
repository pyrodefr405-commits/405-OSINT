import { useRef, useState } from "react";
import { MapPin, Upload, ScanLine, ImagePlay } from "lucide-react";
import { toast } from "sonner";
import { API, streamSSE } from "@/lib/api";
import { useCase } from "@/context/CaseContext";

export default function GeoTool() {
  const inputRef = useRef(null);
  const fullRef = useRef("");
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const { record } = useCase();

  const pick = (f) => {
    setFile(f);
    setOutput("");
    setPreview(f ? URL.createObjectURL(f) : null);
  };

  const analyze = async (target) => {
    const f = target || file;
    if (!f) return toast.error("Sélectionnez une photo d'abord");
    setLoading(true);
    setOutput("");
    fullRef.current = "";
    try {
      const fd = new FormData();
      fd.append("file", f);
      const res = await fetch(`${API}/geolocate`, { method: "POST", body: fd });
      if (!res.ok) throw new Error((await res.json()).detail || "Erreur d'analyse");
      await streamSSE(res, (d) => {
        if (d.error) toast.error(d.error);
        if (d.content) {
          fullRef.current += d.content;
          setOutput((prev) => prev + d.content);
        }
        if (d.done && fullRef.current) record("geo", { texte: fullRef.current.slice(0, 4000) });
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  const loadDemo = async () => {
    try {
      const res = await fetch("/demo-photo.jpg");
      if (!res.ok) throw new Error();
      const blob = await res.blob();
      const f = new File([blob], "photo-demo.jpg", { type: "image/jpeg" });
      pick(f);
      toast.success("Photo d'exemple chargée — analyse en cours");
      analyze(f);
    } catch {
      toast.error("Photo d'exemple indisponible");
    }
  };

  return (
    <div className="bg-[var(--c-surface)] p-6 sm:p-8" data-testid="geo-tool">
      <div className="flex items-baseline justify-between mb-6">
        <h3 className="font-display uppercase text-xl sm:text-2xl flex items-center gap-3">
          <MapPin className="w-5 h-5 text-[var(--c-muted)]" /> Géolocalisation visuelle
        </h3>
        <span className="text-[0.6rem] tracking-[0.3em] text-[var(--c-faint)]">02</span>
      </div>
      <p className="text-xs text-[var(--c-muted)] font-light mb-6 leading-relaxed">
        L'IA vision analyse la photo (végétation, architecture, signalétique...) et estime le lieu de prise de vue.
      </p>
      <div className="flex flex-col sm:flex-row flex-wrap gap-3">
        <button type="button" data-testid="geo-file-btn" onClick={() => inputRef.current?.click()} className="btn-brutal flex items-center justify-center gap-2 flex-1">
          <Upload className="w-3 h-3" /> {file ? file.name.slice(0, 24) : "Choisir une photo"}
        </button>
        <input ref={inputRef} type="file" accept="image/*" className="hidden" data-testid="geo-file-input"
          onChange={(e) => pick(e.target.files?.[0] || null)} />
        <button type="button" data-testid="geo-demo-btn" onClick={loadDemo} disabled={loading} className="btn-brutal !border-[var(--c-faint)] !text-[var(--c-muted)] hover:!border-[var(--c-accent)] flex items-center gap-2">
          <ImagePlay className="w-3 h-3" /> Photo d'exemple
        </button>
        <button type="button" data-testid="geo-analyze-btn" onClick={() => analyze()} disabled={loading} className="btn-brutal flex items-center gap-2">
          <ScanLine className="w-3 h-3" /> {loading ? "Analyse IA..." : "Localiser"}
        </button>
      </div>
      {(preview || output) && (
        <div className="mt-6 border border-[var(--c-border)]" data-testid="geo-results">
          {preview && <img src={preview} alt="Photo analysée" className="w-full max-h-48 object-cover grayscale border-b border-[var(--c-border)]" data-testid="geo-preview" />}
          <pre className={`px-4 py-4 text-xs leading-relaxed whitespace-pre-wrap font-light text-[var(--c-text2)] max-h-72 overflow-y-auto ${loading ? "type-caret" : ""}`} data-testid="geo-output">
            {output || (loading ? "Initialisation du réseau neural..." : "")}
          </pre>
        </div>
      )}
    </div>
  );
}
