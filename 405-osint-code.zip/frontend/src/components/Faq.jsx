import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, MessageCircleQuestion } from "lucide-react";
import SuckSection from "@/components/SuckSection";

const FAQS = [
  {
    q: "L'OSINT, c'est quoi exactement ?",
    a: "Le renseignement en source ouverte : l'art de croiser des informations déjà publiques (réseaux sociaux, annuaires, métadonnées, registres) pour mener une enquête. Aucun piratage, aucune intrusion — uniquement ce qui est accessible à tous.",
  },
  {
    q: "C'est vraiment légal ?",
    a: "Oui, tant qu'on reste sur des sources publiques et dans le respect du RGPD. ARGUS est verrouillé pour ça : il refuse toute demande de piratage, doxxing ou harcèlement, et redirige vers une méthode légale.",
  },
  {
    q: "Que deviennent les photos que j'envoie ?",
    a: "Elles sont analysées à la volée puis oubliées : aucune photo n'est conservée sur nos serveurs. Seul l'historique de ta conversation avec l'IA est gardé pour ta session — le bouton « Nouvelle session » repart de zéro.",
  },
  {
    q: "Comment l'IA devine le lieu d'une photo ?",
    a: "Pas de magie : elle lit les indices visuels comme un enquêteur — végétation, architecture, signalisation, véhicules, météo, relief. Elle donne toujours ses hypothèses avec les indices observés et un niveau de confiance honnête.",
  },
  {
    q: "Pourquoi ma photo n'a aucune donnée EXIF ?",
    a: "Les réseaux sociaux et messageries (Instagram, WhatsApp, Snapchat...) suppriment les métadonnées à l'envoi. Pour retrouver le GPS, l'appareil et la date, il faut le fichier original, sorti directement du téléphone ou de l'appareil photo.",
  },
  {
    q: "La géolocalisation IP est-elle exacte ?",
    a: "Elle donne la zone du fournisseur d'accès — niveau ville, jamais une adresse précise. C'est un point de départ d'enquête, pas une preuve. Un VPN ou un proxy fausse volontairement ce résultat, et ARGUS te le signale.",
  },
  {
    q: "Comment vous contacter ?",
    a: "Sur Discord : y8dqq. Questions, idées de modules, signalement de bug — le canal est ouvert.",
  },
];

export default function Faq() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" data-testid="faq-section" className="border-t border-[var(--c-border)] bg-[var(--c-bg)]">
      <SuckSection>
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-20 sm:py-28">
          <p className="text-[0.65rem] uppercase tracking-[0.35em] text-[var(--c-faint)] mb-4">// Débriefing</p>
          <h2 className="font-display uppercase text-4xl sm:text-6xl leading-none tracking-tight" data-testid="faq-heading">
            Questions<br />fréquentes
          </h2>

          <div className="mt-14 max-w-4xl border border-[var(--c-border)]" data-testid="faq-list">
            {FAQS.map((item, i) => (
              <div key={i} className={i > 0 ? "border-t border-[var(--c-border)]" : ""} data-testid={`faq-item-${i}`}>
                <button
                  type="button"
                  data-testid={`faq-question-${i}`}
                  onClick={() => setOpen(open === i ? -1 : i)}
                  className="w-full flex items-center justify-between gap-4 px-5 sm:px-6 py-5 text-left hover:bg-[var(--c-surface)] transition-colors duration-200"
                >
                  <span className="flex items-center gap-3 text-sm sm:text-base font-bold uppercase tracking-wider">
                    <MessageCircleQuestion className="w-4 h-4 text-[var(--c-accent)] shrink-0" />
                    {item.q}
                  </span>
                  <motion.span animate={{ rotate: open === i ? 45 : 0 }} transition={{ duration: 0.25, ease: "easeOut" }}>
                    <Plus className="w-4 h-4 text-[var(--c-muted)] shrink-0" />
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {open === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="px-5 sm:px-6 pb-6 pl-12 sm:pl-13 text-xs sm:text-sm font-light text-[var(--c-muted)] leading-relaxed" data-testid={`faq-answer-${i}`}>
                        {item.a}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </SuckSection>
    </section>
  );
}
