import ExifTool from "@/components/tools/ExifTool";
import GeoTool from "@/components/tools/GeoTool";
import IpLookup from "@/components/tools/IpLookup";
import NameSearch from "@/components/tools/NameSearch";
import ReverseSearch from "@/components/tools/ReverseSearch";
import SuckSection from "@/components/SuckSection";

export default function Tools() {
  return (
    <section id="outils" data-testid="tools-section" className="border-t border-[var(--c-border)] bg-[var(--c-bg)]">
      <SuckSection>
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-20 sm:py-28">
          <p className="text-[0.65rem] uppercase tracking-[0.35em] text-[var(--c-faint)] mb-4">// Modules opérationnels</p>
          <h2 className="font-display uppercase text-4xl sm:text-6xl leading-none tracking-tight" data-testid="tools-heading">
            Boîte à outils<br />de l'enquêteur
          </h2>
          <p className="mt-6 max-w-lg text-sm font-light text-[var(--c-muted)] leading-relaxed">
            Cinq modules réellement fonctionnels. Aucune donnée n'est conservée après analyse.
            Sources publiques uniquement.
          </p>
          <div className="mt-14 grid grid-cols-1 lg:grid-cols-2 gap-px bg-[var(--c-border)] border border-[var(--c-border)]">
            <ExifTool />
            <GeoTool />
            <IpLookup />
            <NameSearch />
            <ReverseSearch />
          </div>
        </div>
      </SuckSection>
    </section>
  );
}
