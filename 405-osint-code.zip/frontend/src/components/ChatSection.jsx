import { useEffect, useRef, useState } from "react";
import { TerminalSquare, Send, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { API, streamSSE } from "@/lib/api";
import SuckSection from "@/components/SuckSection";

const WELCOME = {
  role: "assistant",
  content: "405 INTEL en ligne. Agent d'investigation OSINT légal à votre service.\n\nJe peux vous aider à :\n- Structurer une enquête sur sources ouvertes\n- Interpréter des métadonnées EXIF\n- Localiser un lieu depuis une photo\n- Construire des requêtes Google dorks\n- Vérifier une image ou une identité publique\n\nPosez votre question.",
};

export default function ChatSection() {
  const [sessionId, setSessionId] = useState(() => localStorage.getItem("argus_session") || null);
  const [messages, setMessages] = useState([WELCOME]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (!sessionId) return;
    fetch(`${API}/chat/history/${sessionId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.messages?.length) setMessages([WELCOME, ...d.messages]);
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    setLoading(true);
    setMessages((prev) => [...prev, { role: "user", content: text }, { role: "assistant", content: "" }]);
    try {
      const res = await fetch(`${API}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, session_id: sessionId }),
      });
      if (!res.ok) throw new Error((await res.json()).detail || "Erreur réseau");
      await streamSSE(res, (d) => {
        if (d.session_id && d.session_id !== sessionId) {
          setSessionId(d.session_id);
          localStorage.setItem("argus_session", d.session_id);
        }
        if (d.error) toast.error(d.error);
        if (d.content) {
          setMessages((prev) => {
            const copy = [...prev];
            copy[copy.length - 1] = { role: "assistant", content: copy[copy.length - 1].content + d.content };
            return copy;
          });
        }
      });
    } catch (e) {
      toast.error(e.message);
      setMessages((prev) => prev.slice(0, -1));
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    localStorage.removeItem("argus_session");
    setSessionId(null);
    setMessages([WELCOME]);
  };

  return (
    <section id="ia" data-testid="chat-section" className="border-t border-[var(--c-border)] bg-[var(--c-bg)] grain relative">
      <SuckSection className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-20 sm:py-28">
          <p className="text-[0.65rem] uppercase tracking-[0.35em] text-[var(--c-faint)] mb-4">// Canal sécurisé ouvert</p>
          <h2 className="font-display uppercase text-4xl sm:text-6xl leading-none tracking-tight" data-testid="chat-heading">
            Parlez à<br />405 Intel
          </h2>
          <p className="mt-6 max-w-lg text-sm font-light text-[var(--c-muted)] leading-relaxed">
            405 Intel est entraîné pour les méthodologies OSINT légales. Il guide votre enquête étape par étape,
            propose des outils publics et refuse toute action illégale.
          </p>

          <div className="mt-14 border border-[var(--c-border)] bg-[var(--c-surface)] max-w-4xl" data-testid="chat-window">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--c-border)]">
              <div className="flex items-center gap-2 text-[0.65rem] uppercase tracking-[0.25em] text-[var(--c-muted)]">
                <TerminalSquare className="w-4 h-4" /> 405INTEL://terminal — session {sessionId ? sessionId.slice(0, 8) : "nouvelle"}
              </div>
              <button type="button" data-testid="chat-reset-btn" onClick={reset} className="text-[0.6rem] uppercase tracking-[0.2em] text-[var(--c-faint)] hover:text-white transition-colors duration-200 flex items-center gap-1">
                <RotateCcw className="w-3 h-3" /> Nouvelle session
              </button>
            </div>

            <div ref={scrollRef} className="h-[26rem] overflow-y-auto px-4 py-6 space-y-6" data-testid="chat-messages">
              {messages.map((m, i) => (
                <div key={i} className={`text-xs sm:text-sm leading-relaxed whitespace-pre-wrap font-light ${m.role === "user" ? "text-white" : "text-[var(--c-muted)]"}`}
                  data-testid={`chat-message-${m.role}-${i}`}>
                  <span className={`text-[0.6rem] uppercase tracking-[0.25em] block mb-1 ${m.role === "user" ? "text-[var(--c-faint)]" : "text-[var(--c-accent)] font-bold"}`}>
                    {m.role === "user" ? "> VOUS" : "> 405 INTEL"}
                  </span>
                  <span className={loading && i === messages.length - 1 && m.role === "assistant" ? "type-caret" : ""}>
                    {m.content}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t border-[var(--c-border)] flex">
              <input data-testid="chat-input" className="input-brutal !border-0 flex-1" placeholder="Interrogez 405 Intel sur votre enquête..."
                value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} />
              <button type="button" data-testid="chat-send-btn" onClick={send} disabled={loading || !input.trim()}
                className="px-6 border-l border-[var(--c-border)] hover:bg-[var(--c-accent)] hover:text-black transition-colors duration-200 disabled:opacity-30">
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </SuckSection>
    </section>
  );
}
