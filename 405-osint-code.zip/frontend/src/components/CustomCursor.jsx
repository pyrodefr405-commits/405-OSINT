import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export default function CustomCursor() {
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 500, damping: 40, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 500, damping: 40, mass: 0.4 });
  const [hovering, setHovering] = useState(false);

  useEffect(() => {
    const move = (e) => { x.set(e.clientX); y.set(e.clientY); };
    const over = (e) => setHovering(!!e.target.closest("a, button, input, [data-testid$='btn']"));
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseover", over);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseover", over);
    };
  }, [x, y]);

  return (
    <motion.div
      className="custom-cursor"
      style={{ x: sx, y: sy }}
      animate={{ scale: hovering ? 1.7 : 1, opacity: hovering ? 0.9 : 1 }}
      transition={{ duration: 0.15, ease: "easeOut" }}
      data-testid="custom-cursor"
    >
      <span className="cc-corner cc-tl" />
      <span className="cc-corner cc-tr" />
      <span className="cc-corner cc-bl" />
      <span className="cc-corner cc-br" />
      <span className="cc-dot" />
    </motion.div>
  );
}
